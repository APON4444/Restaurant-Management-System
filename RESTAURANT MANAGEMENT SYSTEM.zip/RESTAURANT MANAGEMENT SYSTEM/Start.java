import classes.*;

public class Start {

        public static void main(String[] args)
        {
            new Homepage();
			
        }
    }

