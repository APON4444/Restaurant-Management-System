package classes;
import Interface.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class AdminHome extends JFrame implements ActionListener {

    private JPanel panel;
    private JButton employee;
    private JButton accounts;
    private JButton changepassword, logout;
    private JLabel iad;
	private User x;


    public AdminHome(User a) {
		
		x=a;
		
		
        panel = new JPanel();
        panel.setLayout(null);
        add(panel);
		

        Icon iadi = new ImageIcon("Image/adminpanel.png");
        iad = new JLabel(iadi);
        iad.setBounds(0, 0, 850, 550);
        panel.add(iad);

        employee = new JButton("Employee");
        employee.setFont(new Font("Inter", Font.BOLD, 24));
        employee.setBounds(641, 65, 184, 48);
        employee.setFocusable(false);
        employee.setBackground(Color.decode("#E0001A"));
        employee.setForeground(Color.decode("#FFFFFF"));
        employee.setCursor(new Cursor(Cursor.HAND_CURSOR));
        employee.setBorder(BorderFactory.createEtchedBorder());
        employee.addActionListener(this);
        panel.add(employee);


        accounts = new JButton("Accounts");
        accounts.setFont(new Font("Inter", Font.BOLD, 24));
        accounts.setBounds(641, 155, 184, 48);
        accounts.setFocusable(false);
        accounts.setBackground(Color.decode("#E0001A"));
        accounts.setForeground(Color.decode("#FFFFFF"));
        accounts.setCursor(new Cursor(Cursor.HAND_CURSOR));
        accounts.setBorder(BorderFactory.createEtchedBorder());
        accounts.addActionListener(this);
        panel.add(accounts);


        changepassword = new JButton("Change Password");
        changepassword.setFont(new Font("Inter", Font.BOLD, 16));
        changepassword.setBounds(641, 245, 184, 48);
        changepassword.setFocusable(false);
        changepassword.setBackground(Color.decode("#E0001A"));
        changepassword.setForeground(Color.decode("#FFFFFF"));
        changepassword.setCursor(new Cursor(Cursor.HAND_CURSOR));
        changepassword.setBorder(BorderFactory.createEtchedBorder());
        panel.add(changepassword);

        logout = new JButton("Log Out");
        logout.setFont(new Font("Inter", Font.BOLD, 24));
        logout.setBounds(641, 405, 184, 48);
        logout.setFocusable(false);
        logout.setBackground(Color.decode("#000000"));
        logout.setForeground(Color.decode("#FFFFFF"));
        logout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logout.setBorder(BorderFactory.createEtchedBorder());
        logout.addActionListener(this);
        panel.add(logout);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 550);
        setResizable(true);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == logout) {
            new Homepage();
            dispose(); 
        }

        if (e.getSource() == employee) {
            new UserData(x);
            dispose(); 
        }
		else if (e.getSource() == accounts) {
            new Accounts(x);
            setVisible(false); 
        }
    }

    
}
