package classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.LineBorder;

public class exit extends JFrame implements ActionListener{
	
	
	private JLabel logo;
	private JButton exitbtn;
	
public exit(){
		
		super("CONTRIBUTION");
        setSize(800,630);
        setResizable(false);
        setLayout(null);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		ImageIcon bannerIcon = new ImageIcon("Image/exit.png");
        ImageIcon logoIcon = new ImageIcon("Image/logo.png");
        setIconImage(logoIcon.getImage());
		
		logo = new JLabel(bannerIcon);
        logo.setBounds(0,0,800,600);
        add(logo);
		
		setVisible(true);
		
		exitbtn = new JButton("THANK YOU");
        exitbtn.setFont(new Font("Segoe UI", Font.BOLD,20));
        exitbtn.setBounds(330,480,171,36);
        exitbtn.setBorder(new LineBorder(Color.BLACK, 2));
        exitbtn.setBackground(Color.WHITE);
        exitbtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exitbtn.setForeground(Color.BLACK);
        exitbtn.addActionListener(this);
        exitbtn.setFocusable(false);
        add(exitbtn);
		
}
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == exitbtn) {
            System.exit(0);
       
        }
}
}