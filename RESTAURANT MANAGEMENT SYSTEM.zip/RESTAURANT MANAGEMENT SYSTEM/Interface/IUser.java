package Interface;
import classes.*;

public interface IUser {
    String getname();
    String getPassword();
}
